SATURDAY · SURF PACK
Where the surf meets the sky. Gold Coast, Australia.

What's inside
  - saturday-wallpaper-desktop-001.jpg  (571 KB)
  - saturday-wallpaper-desktop-surf.jpg  (641 KB)
  - saturday-phone-001.jpg  (608 KB)
  - saturday-phone-maxing.jpg  (372 KB)
  - saturday-sticker-001-art.png  (803 KB)
  - saturday-sticker-tagline-ribbon.png  (74 KB)

Desktop wallpapers: 2560 x 1440. Phone backgrounds: 1290 x 2796.
Stickers: transparent PNGs with die-cut style borders. The A4 sheets print at 300 dpi
(print at 100% / actual size, then cut along the dashed lines).
The QR on the QR stickers opens the Saturday AR Experience:
  https://saturdayforthewin.com/ar/
Scan it, summon the hologram, then tap "View in your space" on your phone.

Free for personal use: screens, laptops, boards, fridges, eskies.
Not for resale. Saturday, Gold Coast.
