SATURDAY · HOLOGRAM PACK
Where the surf meets the sky. Gold Coast, Australia.

What's inside
  - saturday-wallpaper-desktop-hologram.jpg  (280 KB)
  - saturday-wallpaper-desktop-colour-field.jpg  (136 KB)
  - saturday-phone-hologram.jpg  (278 KB)
  - saturday-phone-colour-field.jpg  (121 KB)
  - saturday-sticker-alien-mark-white.png  (324 KB)
  - saturday-sticker-alien-mark-gold.png  (376 KB)
  - saturday-sticker-alien-badge.png  (242 KB)
  - saturday-ar-qr-sticker-sheet-a4.pdf  (1.0 MB)
  - saturday-ar-qr.png  (792 KB)
  - saturday-ar-qr.svg  (48 KB)

Desktop wallpapers: 2560 x 1440. Phone backgrounds: 1290 x 2796.
Stickers: transparent PNGs with die-cut style borders. The A4 sheets print at 300 dpi
(print at 100% / actual size, then cut along the dashed lines).
The QR on the QR stickers opens the Saturday AR Experience:
  https://saturdayforthewin.com/ar/
Scan it, summon the hologram, then tap "View in your space" on your phone.

Free for personal use: screens, laptops, boards, fridges, eskies.
Not for resale. Saturday, Gold Coast.
